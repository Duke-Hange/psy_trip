# fs_preproc_meg

example pipeline to perform simple minimal preprocessing of raw MEG data and basic decoding using fs_cvmanova (Sandhaeger et al., PLOS Biology, 2023)

run fs_preproc_pipeline.m after downloading example data and setting paths

fieldtrip needs to be added to the path

example data can be found at https://osf.io/vj459/?view_only=3bf0c92790c74224970c9f577705cc45

when using fs_cvmanova, please cite:
Sandhaeger et al., PLOS Biology, 2023; 
Allefeld & Haynes, NeuroImage, 2014
